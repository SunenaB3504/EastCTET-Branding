# Privacy Policy — EasyCTET

**Last updated:** [Insert date on publish]

This Privacy Policy explains how EasyCTET ("we," "us," "our," "the App") handles information in connection with the EasyCTET mobile application and the easyctet.in website (together, "the Service"). We built EasyCTET around one core principle: **your study habits are your business, not ours.**

---

## 1. Our Data Philosophy

EasyCTET is designed to work **100% offline**, and the App collects **zero telemetry**. In practical terms, this means:

- We do not track which questions you answer, how long you spend studying, which topics you're weak in, or any other in-app behavior.
- We do not use third-party analytics SDKs, ad-tracking libraries, or behavioral profiling tools inside the App.
- Your quiz scores, progress, and study history are stored **only on your own device** and are never transmitted to us.

This section is a summary of our practice — the details below cover the few situations where limited information is handled.

---

## 2. Information We Do Not Collect

We do not collect, store, or have access to:
- Your quiz answers, scores, or study progress
- Your device's location
- Your contacts, photos, or files
- Advertising identifiers or behavioral tracking data
- Any usage analytics from within the App

---

## 3. Information You May Choose to Provide

Some parts of the Service require a small amount of information, provided voluntarily by you:

- **Referral Program**: if you choose to refer a friend, we may ask for a way to share your referral code or link (e.g., via your own messaging apps). We do not access your contact list to do this.
- **Pro Pass Purchases**: purchases are processed entirely through Google Play Billing. We do not receive or store your payment card details, UPI information, or any other financial data — that is handled directly by Google under Google's own privacy policy.
- **Contacting Us**: if you email us (for support, feedback, or otherwise), we will have access to your email address and the content of your message, used only to respond to you.

---

## 4. Children's Privacy

EasyCTET is designed for adult CTET aspirants preparing to become teachers. It is not directed at, marketed to, or intended for use by children under the age of 13, and we do not knowingly collect information from children.

---

## 5. Data Security

Because the App does not transmit your study data anywhere, there is nothing for us to secure on our end — your information stays on your device, protected by your device's own security. Any limited data you do share with us directly (such as a support email) is handled with reasonable care and is not sold or shared with third parties for advertising purposes.

---

## 6. Third-Party Services

The only third-party service involved in the Service is **Google Play Billing**, used solely to process Pro Pass purchases. Google's handling of that transaction data is governed by Google's own Privacy Policy, not this one.

---

## 7. Your Rights

Since we hold minimal to no personal data about you, there is generally nothing for us to access, correct, or delete on your behalf beyond any direct correspondence (such as support emails), which you may ask us to delete at any time by writing to us.

---

## 8. Changes to This Policy

We may update this Privacy Policy from time to time, for example to reflect new features. We'll update the "Last updated" date above when we do. Continued use of the Service after changes means you accept the updated policy.

---

## 9. Contact Us

If you have questions about this Privacy Policy, write to us at:
**[support@easyctet.in]**

---

*This policy reflects EasyCTET's actual data practices as of the date above. It has been drafted to align with general principles under India's Digital Personal Data Protection Act, 2023, and Google Play's Data Safety requirements — but is a starting template, not a substitute for review by a qualified legal professional before publishing, particularly once Pro Pass billing and the referral program are finalized.*
