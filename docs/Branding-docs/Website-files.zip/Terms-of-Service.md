# Terms of Service — EasyCTET

**Last updated:** [Insert date on publish]

Welcome to EasyCTET. These Terms of Service ("Terms") govern your use of the EasyCTET mobile application and the easyctet.in website (together, "the Service"), operated by [Your Name / Business Name], India. By downloading, accessing, or using the Service, you agree to these Terms.

---

## 1. What EasyCTET Is

EasyCTET is an educational preparation tool for CTET (Central Teacher Eligibility Test) Paper 1, Primary level, offering practice quizzes, study guides, and audio masterclasses across five subjects: Child Development & Pedagogy, English, Hindi, Mathematics, and Environmental Studies.

**EasyCTET is a study aid, not a guarantee.** We've built the content to closely match the CTET exam pattern and standard, but we do not guarantee any particular score, result, or exam outcome from using the Service.

---

## 2. Eligibility

The Service is intended for adult users preparing for the CTET examination. By using the Service, you confirm you are using it for personal, non-commercial study purposes.

---

## 3. Free Tier & Pro Pass

- The App offers a **Free tier** with limited access to questions, study guides, and audio content.
- **Pro Pass** is a paid tier unlocking the full question bank, complete study guides, and the full audio masterclass library across all 5 subjects.
- Pro Pass purchases are processed through **Google Play Billing**. Pricing, billing cycles, and refund eligibility are subject to Google Play's own policies in addition to these Terms.
- We reserve the right to change Pro Pass pricing or features with reasonable notice; existing purchases will not be retroactively devalued for their paid period.

---

## 4. Referral Program

- EasyCTET may offer referral rewards (e.g., additional Pro Pass days) to users who refer new users, as described in the App at the time.
- Referral rewards have no cash value, cannot be exchanged for money, and may be modified, limited, or discontinued at our discretion.
- We reserve the right to withhold or reverse referral rewards obtained through fraudulent activity, fake accounts, or abuse of the program.
- *[Final referral mechanics to be confirmed — see accompanying draft for the proposed structure.]*

---

## 5. Content & Intellectual Property

- All questions, study guides, explanations, and audio content within EasyCTET are **originally authored** for EasyCTET and are not copied from official CBSE/CTET past papers or any third-party source.
- All content is the intellectual property of EasyCTET and may not be copied, redistributed, resold, or reproduced elsewhere without written permission.
- The EasyCTET name, logo, and tagline are marks of [Your Name / Business Name].

---

## 6. Acceptable Use

You agree not to:
- Reverse-engineer, scrape, or extract the App's question bank for redistribution
- Use automated tools to abuse the referral program
- Use the Service for any unlawful purpose

---

## 7. Disclaimer of Warranties

The Service is provided "as is." While we take care to ensure content accuracy and alignment with the CTET syllabus and pattern (NCERT, NCF, and NEP guidelines), we make no warranty that the Service is error-free, uninterrupted, or that it guarantees exam success. CTET is conducted by CBSE, and EasyCTET is an independent, unaffiliated preparation tool.

---

## 8. Limitation of Liability

To the maximum extent permitted by law, EasyCTET and its operator shall not be liable for any indirect, incidental, or consequential damages arising from your use of, or inability to use, the Service — including exam outcomes.

---

## 9. Changes to the Service or Terms

We may update these Terms or modify, suspend, or discontinue features of the Service at any time. Material changes will be reflected by updating the "Last updated" date above.

---

## 10. Governing Law

These Terms are governed by the laws of India. Any disputes shall be subject to the jurisdiction of the courts of [Your City], Maharashtra.

---

## 11. Contact Us

Questions about these Terms can be sent to:
**[support@easyctet.in]**

---

*This is a template drafted from the details you've provided. Recommend a review by a qualified legal professional in India before publishing — particularly the referral program and Pro Pass billing sections, since those terms carry real consumer-facing obligations once finalized.*
