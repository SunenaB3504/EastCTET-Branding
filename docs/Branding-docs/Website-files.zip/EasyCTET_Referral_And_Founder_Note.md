# Referral Draft & Founder's Note — Ready to Drop Into the Site

## Referral Program (Draft — to Finalize)

A simple two-sided structure, easy to explain in one line on the site:

**Primary mechanic:**
> *"Invite a friend to EasyCTET — when they install and complete their first quiz, you both get 7 days of Pro Pass free."*

**Milestone bonus (optional, adds a reason to keep sharing):**
> *"Refer 3 friends who join → unlock 30 days of Pro Pass free."*

**Why this structure:**
- Two-sided (both people benefit) drives most of the sharing — one-sided referral offers convert far less
- Tying the reward to "completes their first quiz," not just install, avoids rewarding installs that never actually engage
- A milestone tier (3 referrals → bigger reward) gives motivated users a reason to share more than once, without needing an open-ended points system

**Still to decide before this goes live:**
- Exact day counts (7 / 30 used above are placeholders — adjust to whatever your Pro Pass margins support)
- Whether referral rewards stack indefinitely or cap at a maximum
- Fraud prevention: the Terms of Service draft already includes a clause reserving the right to withhold rewards from fraudulent referrals — worth deciding what "fraudulent" means in practice (e.g., same device installing multiple times)

This mechanic is already reflected in the Privacy Policy and Terms of Service drafts, written generically enough to hold regardless of which exact numbers you land on.

---

## Founder's Note (for the Social Proof / Trust section)

Since there's no formal education-domain credential to lean on, the honest and genuinely compelling angle here is **technical rigor + real-world validation** — not manufactured authority. Here's a draft:

> **Built by an engineer, tested by a teacher.**
> EasyCTET was built by a software professional with over 35 years in the IT industry — applying the same rigor used in enterprise software to how CTET content is structured, checked, and delivered. But the real test isn't in the code. My wife, a working teacher, is preparing for this very CTET exam — and she's using EasyCTET to do it. If it doesn't hold up for her, it doesn't ship.

**Why this framing works better than a generic "About the Founder" bio:**
- It doesn't overclaim education expertise you don't have — it's honest about where the credibility actually comes from (engineering rigor)
- "Tested by a teacher, for a teacher" is a genuinely strong trust signal — it's a real person, in the real exam, not a marketing claim
- It quietly reinforces "originally authored, carefully checked" without repeating that phrase again

**One decision left to you:** whether to name your wife directly (adds warmth and specificity) or keep it as "my wife, a working teacher" (keeps her private). I've kept the draft above anonymous by default — easy to add her name later if you'd like the extra personal touch.

---

## Confirmed / No Action Needed

- **Screenshots**: placeholders remain in the Website Plan and Website Copy exactly where they were — swap in your real screenshots whenever they're ready, no structural changes needed.
- **Subject-wise sample questions**: keeping the illustrative ones as-is (already reflected — no changes made to `EasyCTET_Subject_Wise_Content.md` questions themselves, only the question-count figures were corrected to the real 150-per-subject / 750-total numbers).
